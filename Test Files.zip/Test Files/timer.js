function setRAFInterval(functionToBeExecuted, timeInterval) {
  var currentTime = performance.now();
  var executor = function (time) {
    if (performance.now() - currentTime < timeInterval) {
      requestAnimationFrame(executor);
      return;
    }

    currentTime = performance.now();
    functionToBeExecuted(time);
    requestAnimationFrame(executor);
  }

  requestAnimationFrame(executor);
}